/*************************************
* Lab 1 Exercise 2
* Name: Chee You
* Student No: A0188719j
* Lab Group: 01
*************************************/

//declare your func_list array here
//remember to add in the keyword - extern

 void update_functions();
extern int (*func_list[5]) (int x);

